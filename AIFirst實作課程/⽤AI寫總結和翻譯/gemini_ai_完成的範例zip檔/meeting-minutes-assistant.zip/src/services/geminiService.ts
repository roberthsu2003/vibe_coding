import { GoogleGenAI } from '@google/genai';

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
});

export const SYSTEM_INSTRUCTION = `You are an expert meeting minutes assistant and professional business translator. 
The user will provide a meeting transcript or key notes. 
Your task is to reorganize and summarize the content into a formatted report according strictly to the following Markdown structure:

### 1. 會議摘要 (Executive Summary)
[Write 3-5 sentences concisely summarizing the core purpose and conclusions of the meeting in Traditional Chinese.]

### 2. 重點討論事項 (Key Discussions)
[Use bullet points to format the key discussions, organized by speaker or department in Traditional Chinese.]

### 3. 待辦事項清單 (Action Items)
[List all action items explicitly using Markdown checkboxes (- [ ]). Format strictly as: - [ ] Task detail - 負責人: Assignee, 預計完成時間: Deadline. If the assignee or deadline is not specified, intelligently estimate or indicate 'TBD'.]

### 4. 英文翻譯 (English Translation)
#### Executive Summary
[Provide a highly professional business English translation of the Executive Summary (section 1).]

#### Action Items
[Provide a professional business English translation of the Action Items (section 3), maintaining the Markdown checkbox format.]

Do not include any extra introductory or concluding remarks. Just return the requested Markdown format.`;

export async function generateMeetingMinutes(transcript: string): Promise<string> {
  if (!transcript.trim()) {
    throw new Error('輸入內容不能為空');
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-pro',
      contents: {
        role: 'user',
        parts: [{ text: transcript }],
      },
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.2, // Low temperature for factual, precise summaries
      },
    });

    return response.text || '未能產生回應。';
  } catch (error) {
    console.error('產生會議記錄時發生錯誤:', error);
    throw new Error('產生會議記錄失敗，請稍後重試。');
  }
}
