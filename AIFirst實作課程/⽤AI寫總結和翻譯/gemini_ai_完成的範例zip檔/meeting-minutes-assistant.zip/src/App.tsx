import { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { generateMeetingMinutes } from './services/geminiService';
import { FileText, Loader2, Copy, CheckCircle2, FileSignature, ArrowRight } from 'lucide-react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export default function App() {
  const [transcript, setTranscript] = useState('');
  const [result, setResult] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState('');
  const [copied, setCopied] = useState(false);

  const handleGenerate = async () => {
    if (!transcript.trim()) {
      setError('請先輸入會議逐字稿或筆記。');
      return;
    }
    
    setError('');
    setIsGenerating(true);
    
    try {
      const report = await generateMeetingMinutes(transcript);
      setResult(report);
    } catch (err: any) {
      setError(err.message || '產生報告時發生錯誤。');
    } finally {
      setIsGenerating(false);
    }
  };

  const copyToClipboard = async () => {
    if (!result) return;
    try {
      await navigator.clipboard.writeText(result);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('複製文字失敗', err);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-800 font-sans selection:bg-indigo-100">
      <header className="h-16 bg-white border-b border-slate-200 px-8 flex items-center justify-between sticky top-0 z-10">
        <div className="max-w-7xl mx-auto w-full flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-6 h-6 flex items-center justify-center bg-indigo-500 rounded-full">
              <FileSignature className="w-3.5 h-3.5 text-white" />
            </div>
            <h1 className="text-lg font-semibold tracking-tight text-slate-900">
              Minutes Pro<span className="text-slate-400 font-normal"> AI</span>
            </h1>
          </div>
          <div className="px-2 py-1 bg-slate-100 text-slate-600 rounded text-[10px] font-bold uppercase tracking-widest">
            專業會議助理
          </div>
        </div>
      </header>

      <main className="flex-1 w-full max-w-7xl mx-auto px-8 py-8 overflow-hidden">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 h-full">
          
          {/* Left Column: Input */}
          <div className="flex flex-col h-[calc(100vh-10rem)]">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xs font-bold text-indigo-600 uppercase tracking-wider flex items-center gap-2">
                <FileText className="w-4 h-4 text-indigo-500" />
                會議內容輸入
              </h2>
            </div>
            
            <div className="flex-1 bg-white border border-slate-200 rounded-xl shadow-xl shadow-slate-200/50 flex flex-col overflow-hidden focus-within:ring-2 focus-within:ring-indigo-500/20 focus-within:border-indigo-500 transition-all">
              <textarea
                value={transcript}
                onChange={(e) => setTranscript(e.target.value)}
                placeholder="請貼上會議逐字稿、初步筆記或討論重點..."
                className="flex-1 w-full p-6 resize-none outline-none text-slate-700 text-sm leading-relaxed placeholder:text-slate-400 bg-transparent"
              />
              <div className="bg-slate-50/50 p-4 border-t border-slate-100 flex items-center justify-between">
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">
                  {transcript.length > 0 ? `${transcript.length} 字元` : '準備就緒'}
                </span>
                <button
                  onClick={handleGenerate}
                  disabled={isGenerating || !transcript.trim()}
                  className={cn(
                    "flex items-center gap-2 px-4 py-2 rounded-md font-semibold text-xs transition-all duration-200 cursor-pointer shadow-sm",
                    isGenerating || !transcript.trim() 
                      ? "bg-slate-100 text-slate-400 cursor-not-allowed shadow-none" 
                      : "bg-indigo-600 hover:bg-indigo-700 text-white active:scale-95"
                  )}
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      處理中...
                    </>
                  ) : (
                    <>
                      產生報告
                      <ArrowRight className="w-3.5 h-3.5" />
                    </>
                  )}
                </button>
              </div>
            </div>
            {error && (
              <p className="mt-3 text-sm text-red-600 bg-red-50 p-3 rounded-lg border border-red-100">
                {error}
              </p>
            )}
          </div>

          {/* Right Column: Output */}
          <div className="flex flex-col h-[calc(100vh-10rem)]">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xs font-bold text-indigo-600 uppercase tracking-wider">
                結構化會議報告
              </h2>
              {result && (
                <button
                  onClick={copyToClipboard}
                  className="flex items-center gap-1.5 px-3 py-1.5 border border-slate-200 text-slate-600 rounded-md text-xs font-semibold hover:bg-slate-50 transition-colors cursor-pointer active:scale-95 bg-white shadow-sm"
                >
                  {copied ? <CheckCircle2 className="w-3.5 h-3.5 text-green-600" /> : <Copy className="w-3.5 h-3.5" />}
                  {copied ? '已複製！' : '複製內容'}
                </button>
              )}
            </div>
            
            <div className="flex-1 bg-white shadow-xl shadow-slate-200/50 rounded-xl border border-slate-200 flex flex-col overflow-hidden">
              {result ? (
                <div className="p-8 overflow-y-auto w-full h-full flex flex-col space-y-8">
                  <div className="markdown-body text-slate-800 flex-1">
                    <ReactMarkdown remarkPlugins={[remarkGfm]}>
                      {result}
                    </ReactMarkdown>
                  </div>
                  
                  {/* Matching Document Footer from theme */}
                  <div className="pt-8 mt-auto border-t border-slate-100 flex justify-between items-center text-slate-400">
                    <p className="text-[10px] font-medium uppercase italic">文件結尾 — Minutes Pro AI</p>
                    <div className="flex items-center gap-1.5">
                      <div className="w-1.5 h-1.5 rounded-full bg-green-500"></div>
                      <span className="text-[10px] text-slate-500 font-semibold uppercase tracking-wide">已自動存檔</span>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="flex-1 flex flex-col items-center justify-center text-center p-8 bg-slate-50/50">
                  <div className="bg-slate-100 p-4 rounded-full mb-4 ring-4 ring-slate-50">
                    <FileSignature className="w-6 h-6 text-slate-400" />
                  </div>
                  <h3 className="text-slate-900 font-medium text-sm mb-1">尚未產生任何報告</h3>
                  <p className="text-xs text-slate-500 max-w-xs leading-relaxed">
                    請在左側輸入會議筆記，然後點擊「產生報告」，包含中英雙語對照的結構化報告將會顯示於此。
                  </p>
                </div>
              )}
            </div>
          </div>
          
        </div>
      </main>
    </div>
  );
}
