import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Play, RotateCcw, AlertTriangle, Waves, Flag, Ticket, Gamepad2, Mic, CircleDot, Clapperboard, ShieldCheck, Volume2, VolumeX } from 'lucide-react';
import { initAudio, playSound } from './utils/audio';

const CARD_TYPES = [
  { text: "游泳競賽", icon: Waves },
  { text: "高爾夫球賽", icon: Flag },
  { text: "電影票", icon: Ticket },
  { text: "娃娃機", icon: Gamepad2 },
  { text: "卡拉OK", icon: Mic },
  { text: "電動彈珠台", icon: CircleDot },
  { text: "電影院", icon: Clapperboard },
  { text: "納保官", icon: ShieldCheck }
];

type GameState = 'idle' | 'playing' | 'won' | 'lost';

interface CardData {
  id: number;
  text: string;
  icon: any;
  isFlipped: boolean;
  isMatched: boolean;
}

export default function App() {
  const [gameState, setGameState] = useState<GameState>('idle');
  const [cards, setCards] = useState<CardData[]>([]);
  const [flippedIndices, setFlippedIndices] = useState<number[]>([]);
  const [chances, setChances] = useState(15);
  const [timeLeft, setTimeLeft] = useState(45);
  const [isFlippingDisabled, setIsFlippingDisabled] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  
  const bgmRef = useRef<HTMLAudioElement>(null);
  const isMutedRef = useRef(isMuted);

  useEffect(() => {
    isMutedRef.current = isMuted;
    if (bgmRef.current) {
      bgmRef.current.muted = isMuted;
    }
  }, [isMuted]);

  const quitGame = () => {
    setGameState('idle');
    if (bgmRef.current) {
      bgmRef.current.pause();
      bgmRef.current.currentTime = 0;
    }
  };

  const startGame = () => {
    initAudio();
    if (!isMutedRef.current && bgmRef.current) {
      bgmRef.current.currentTime = 0;
      bgmRef.current.play().catch(() => console.warn("依據瀏覽器政策，需使用者互動後才能播放"));
    }
    const shuffled = [...CARD_TYPES, ...CARD_TYPES]
      .sort(() => Math.random() - 0.5)
      .map((card, index) => ({
        id: index,
        text: card.text,
        icon: card.icon,
        isFlipped: false,
        isMatched: false
      }));
    setCards(shuffled);
    setChances(15);
    setTimeLeft(45);
    setFlippedIndices([]);
    setIsFlippingDisabled(false);
    setGameState('playing');
  };

  useEffect(() => {
    let timer: number;
    if (gameState === 'playing' && timeLeft > 0) {
      timer = window.setInterval(() => {
        setTimeLeft(t => {
          if (t <= 1) {
            setGameState('lost');
            clearInterval(timer);
            if (!isMutedRef.current) playSound.lose();
            if (bgmRef.current) bgmRef.current.pause();
            return 0;
          }
          return t - 1;
        });
      }, 1000);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [gameState, timeLeft]);

  const handleCardClick = (index: number) => {
    if (gameState !== 'playing' || isFlippingDisabled) return;
    if (cards[index].isFlipped || cards[index].isMatched) return;

    if (!isMutedRef.current) playSound.flip();

    const newCards = [...cards];
    newCards[index].isFlipped = true;
    setCards(newCards);

    const newFlipped = [...flippedIndices, index];
    setFlippedIndices(newFlipped);

    if (newFlipped.length === 2) {
      setIsFlippingDisabled(true);
      const [firstIndex, secondIndex] = newFlipped;
      const isMatch = newCards[firstIndex].text === newCards[secondIndex].text;

      setChances(c => c - 1);
      const remainingChances = chances - 1;

      if (isMatch) {
        if (!isMutedRef.current) playSound.match();
        newCards[firstIndex].isMatched = true;
        newCards[secondIndex].isMatched = true;
        setCards(newCards);
        setFlippedIndices([]);
        setIsFlippingDisabled(false);

        if (newCards.every(c => c.isMatched)) {
          if (!isMutedRef.current) playSound.win();
          if (bgmRef.current) bgmRef.current.pause();
          setGameState('won');
        } else if (remainingChances <= 0) {
          if (!isMutedRef.current) playSound.lose();
          if (bgmRef.current) bgmRef.current.pause();
          setGameState('lost');
        }
      } else {
        if (!isMutedRef.current) playSound.mismatch();
        setTimeout(() => {
          setCards(currentCards => {
            const resetCards = [...currentCards];
            resetCards[firstIndex].isFlipped = false;
            resetCards[secondIndex].isFlipped = false;
            return resetCards;
          });
          setFlippedIndices([]);
          setIsFlippingDisabled(false);

          if (remainingChances <= 0) {
            if (!isMutedRef.current) playSound.lose();
            if (bgmRef.current) bgmRef.current.pause();
            setGameState('lost');
          }
        }, 1000);
      }
    }
  };

  return (
    <div className="min-h-screen bg-[#1a3a1a] text-white overflow-hidden" style={{ fontFamily: "'PingFang TC', 'Microsoft JhengHei', sans-serif" }}>
      <audio ref={bgmRef} src="/bgm.mp3" loop />
      
      {/* Sound Toggle Button */}
      <button
        onClick={() => {
          setIsMuted(!isMuted);
          initAudio();
          if (!isMuted && bgmRef.current) {
            bgmRef.current.pause();
          } else if (isMuted && bgmRef.current && gameState === 'playing') {
            bgmRef.current.play().catch(()=>{});
          }
        }}
        className="fixed top-4 right-4 z-[60] p-3 bg-black/40 hover:bg-white/20 active:bg-white/30 rounded-full border border-white/10 text-white shadow-xl backdrop-blur-md transition-all"
        title={isMuted ? "開啟聲音" : "靜音"}
      >
        {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
      </button>

      {/* Landscape Warning for Mobile */}
      <div className="hidden landscape:max-md:flex fixed inset-0 z-50 bg-black text-white flex-col items-center justify-center p-10 text-center">
        <div className="text-orange-500 text-5xl mb-4">🔄</div>
        <h2 className="text-2xl font-bold mb-2">此遊戲僅支援直式模式</h2>
        <p className="text-white/80 opacity-80 mt-2">請將裝置轉為直式以獲得最佳體驗</p>
      </div>

      <main className="max-w-md mx-auto h-[100dvh] flex flex-col relative app-container overflow-y-auto landscape:max-md:hidden">
        <AnimatePresence mode="wait">
          {gameState === 'idle' ? (
            <motion.div
              key="start-screen"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="flex-1 flex flex-col items-center justify-center p-6 text-center z-10 space-y-8 my-auto"
            >
              <div className="space-y-4">
                <div className="inline-flex items-center justify-center p-4 bg-black/30 rounded-2xl shadow-inner mb-2 border border-white/10">
                  <Gamepad2 className="w-12 h-12 text-orange-500" />
                </div>
                <h1 className="text-3xl lg:text-4xl font-bold text-white/90 tracking-tight leading-tight">
                  娛樂稅 <span className="text-orange-500 underline underline-offset-4 decoration-2">VS</span> 納保法
                  <br />
                  <span className="text-sm text-gray-400 uppercase tracking-[0.2em] font-normal mt-2 block">Memory Challenge</span>
                </h1>
              </div>

              <div className="bg-black/30 p-6 rounded-2xl border border-white/10 shadow-xl max-w-sm w-full space-y-6">
                <p className="text-gray-300 text-sm md:text-base leading-relaxed font-medium">
                  卡片圖案代表娛樂稅課稅項目與納保法，
                  <br />
                  請在時間與機會限制內完成所有配對喔！
                </p>

                <div className="pt-4 border-t border-white/10 text-left">
                  <p className="text-xs text-gray-400 mb-3 uppercase tracking-widest font-bold">卡牌類型</p>
                  <div className="grid grid-cols-2 gap-2">
                    {CARD_TYPES.map((card, idx) => {
                      const Icon = card.icon;
                      return (
                        <div key={idx} className="flex items-center space-x-2 text-gray-300 text-sm font-medium">
                          <Icon className="w-4 h-4 text-orange-400" />
                          <span>{card.text}</span>
                        </div>
                      )
                    })}
                  </div>
                </div>
              </div>

              <button
                onClick={startGame}
                className="group relative w-full max-w-sm flex items-center justify-center space-x-2 bg-orange-500 hover:bg-orange-400 active:bg-orange-600 text-white p-4 rounded-xl font-bold text-xl transition-all shadow-[0_6px_0_theme(colors.orange.700)] hover:translate-y-[2px] active:shadow-[0_0px_0_theme(colors.orange.700)] active:translate-y-[6px]"
              >
                <Play className="w-6 h-6 fill-current" />
                <span>開始遊戲</span>
              </button>
            </motion.div>
          ) : (
            <motion.div
              key="game-screen"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex-1 flex flex-col p-4 z-10 w-full pt-8"
            >
              {/* Header Stats */}
              <header className="flex items-center justify-between bg-black/30 p-4 rounded-2xl border border-white/10 mb-6 shadow-xl relative z-20">
                <div className="flex flex-col">
                  <span className="text-xs text-gray-400 uppercase tracking-widest mb-1">剩餘機會</span>
                  <span className={`text-3xl font-bold ${chances <= 3 ? 'text-red-500 animate-pulse' : 'text-orange-400'}`}>
                    {chances} <small className="text-sm opacity-50 font-normal">次</small>
                  </span>
                </div>
                <div className="w-px h-10 bg-white/10 mx-2"></div>
                <div className="flex flex-col items-end">
                  <span className="text-xs text-gray-400 uppercase tracking-widest mb-1">剩餘時間</span>
                  <span className={`text-3xl font-bold ${timeLeft <= 10 ? 'text-red-500 animate-pulse' : 'text-orange-400'}`}>
                    {timeLeft} <small className="text-sm opacity-50 font-normal">秒</small>
                  </span>
                </div>
              </header>

              {/* Game Board */}
              <div className="flex-1 flex items-center justify-center relative z-10 pb-4">
                <div className="grid grid-cols-4 gap-3 sm:gap-4 w-full max-w-[400px] aspect-[4/5] sm:aspect-square content-start sm:content-center">
                  {cards.map((card, idx) => (
                    <div
                      key={card.id}
                      className="relative w-full aspect-square perspective-1000 group cursor-pointer"
                      onClick={() => handleCardClick(idx)}
                    >
                      <motion.div
                        className="w-full h-full relative preserve-3d"
                        initial={false}
                        animate={{ rotateY: card.isFlipped || card.isMatched ? 180 : 0 }}
                        transition={{ duration: 0.5, type: "spring", stiffness: 260, damping: 20 }}
                      >
                        {/* Front (Face Down) */}
                        <div className="absolute inset-0 backface-hidden bg-orange-500 rounded-xl shadow-lg border-2 border-orange-400/50 flex items-center justify-center hover:bg-orange-400 transition-colors">
                          <span className="text-3xl sm:text-4xl text-black/20 font-black">?</span>
                        </div>

                        {/* Back (Face Up) */}
                        <div className={`absolute inset-0 backface-hidden rotate-y-180 bg-white text-emerald-900 rounded-xl shadow-inner border-2 flex flex-col items-center justify-center p-1 sm:p-2 transition-all duration-300 ${card.isMatched ? 'border-yellow-400 ring-4 ring-yellow-400' : 'border-white'}`}>
                          <card.icon className="w-8 h-8 sm:w-10 sm:h-10 mb-1 sm:mb-1.5 text-emerald-800" />
                          <span className="text-[10px] sm:text-xs font-bold text-center leading-tight">
                            {card.text}
                          </span>
                        </div>
                      </motion.div>
                    </div>
                  ))}
                </div>
              </div>
              
              <footer className="flex justify-between items-center mt-2 border-t border-white/10 pt-4 opacity-70">
                <div className="text-xs text-white/70 hidden sm:block">
                  課稅項目包括：游泳、高爾夫、電影票等
                </div>
                <div className="flex space-x-2 w-full justify-between sm:w-auto sm:justify-end">
                  <button onClick={quitGame} className="px-4 py-2 sm:py-1.5 bg-red-500/20 hover:bg-red-500/40 active:bg-red-500/50 rounded-lg text-xs sm:text-sm font-medium border border-red-500/30 text-red-100 transition-all">
                    回首頁
                  </button>
                  <button onClick={startGame} className="px-4 py-2 sm:py-1.5 bg-white/10 hover:bg-white/20 active:bg-white/30 rounded-lg text-xs sm:text-sm font-medium border border-white/20 transition-all">
                    重新開始
                  </button>
                </div>
              </footer>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Global Overlays for Win/Loss */}
        <AnimatePresence>
          {(gameState === 'won' || gameState === 'lost') && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 z-50 flex items-center justify-center p-6 bg-black/80 backdrop-blur-sm"
            >
              <motion.div
                initial={{ scale: 0.9, y: 20 }}
                animate={{ scale: 1, y: 0 }}
                className="bg-[#1a3a1a] border border-white/10 p-8 rounded-[2rem] shadow-2xl max-w-sm w-full text-center space-y-6 relative overflow-hidden"
              >
                {/* Decorative background glow */}
                <div className={`absolute -top-10 left-1/2 -translate-x-1/2 w-48 h-48 blur-3xl opacity-30 rounded-full pointer-events-none ${gameState === 'won' ? 'bg-orange-500' : 'bg-red-500'}`}></div>

                {gameState === 'won' ? (
                  <div className="relative z-10 space-y-3">
                    <div className="w-20 h-20 bg-orange-500 rounded-full flex items-center justify-center mx-auto mb-6 shadow-[0_0_30px_theme(colors.orange.500/30)]">
                      <Play className="w-10 h-10 text-white fill-current" />
                    </div>
                    <h2 className="text-3xl font-bold text-white/90">恭喜過關快手！</h2>
                    <p className="text-gray-300 font-medium">你成功配對了所有的卡牌！</p>
                    <div className="pt-4 flex items-center justify-center space-x-4 text-sm font-bold text-orange-300">
                      <div className="bg-black/30 px-4 py-2 rounded-lg border border-white/10">
                        剩餘時間: {timeLeft}s
                      </div>
                      <div className="bg-black/30 px-4 py-2 rounded-lg border border-white/10">
                        剩餘機會: {chances}
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="relative z-10 space-y-3">
                     <div className="w-20 h-20 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-6 shadow-[0_0_30px_theme(colors.red.500/30)] animate-bounce">
                      <AlertTriangle className="w-10 h-10 text-white" />
                    </div>
                    <h2 className="text-3xl font-bold text-white/90">遊戲結束</h2>
                    <p className="text-gray-300 font-medium text-lg">
                      {timeLeft <= 0 ? '時間到了！' : '機會用完了！'}
                    </p>
                  </div>
                )}

                <div className="flex space-x-3 mt-4 relative z-10 w-full">
                  <button
                    onClick={quitGame}
                    className="flex-1 flex items-center justify-center space-x-2 bg-red-500/20 hover:bg-red-500/30 active:bg-red-500/40 text-red-100 p-4 rounded-xl font-bold text-lg border border-red-500/30 transition-all duration-200"
                  >
                    <span>回首頁</span>
                  </button>
                  <button
                    onClick={startGame}
                    className="flex-[2] flex items-center justify-center space-x-2 bg-white/10 hover:bg-white/20 active:bg-white/30 text-white p-4 rounded-xl font-bold text-lg border border-white/20 transition-all duration-200"
                  >
                    <RotateCcw className="w-6 h-6" />
                    <span>再玩一次</span>
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}
