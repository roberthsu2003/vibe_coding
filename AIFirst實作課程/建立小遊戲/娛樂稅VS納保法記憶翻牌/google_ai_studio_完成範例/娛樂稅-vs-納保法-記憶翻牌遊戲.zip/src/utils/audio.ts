const getAudioContext = () => {
  const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
  return new AudioContextClass();
};

let ctx: AudioContext | null = null;

export const initAudio = () => {
  if (!ctx) {
    ctx = getAudioContext();
  }
  if (ctx.state === 'suspended') {
    ctx.resume();
  }
};

const playTone = (freq: number, type: OscillatorType, duration: number, vol: number = 0.1) => {
  if (!ctx) return;
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, ctx.currentTime);

  // Envelope to prevent popping clicks
  gain.gain.setValueAtTime(0, ctx.currentTime);
  gain.gain.linearRampToValueAtTime(vol, ctx.currentTime + 0.02);
  gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);

  osc.connect(gain);
  gain.connect(ctx.destination);
  osc.start();
  osc.stop(ctx.currentTime + duration);
};

export const playSound = {
  flip: () => {
    playTone(300, 'sine', 0.1, 0.05);
    setTimeout(() => playTone(450, 'sine', 0.1, 0.05), 40);
  },
  match: () => {
    playTone(523.25, 'sine', 0.1, 0.1); 
    setTimeout(() => playTone(659.25, 'sine', 0.1, 0.1), 80);  
    setTimeout(() => playTone(783.99, 'sine', 0.2, 0.1), 160); 
  },
  mismatch: () => {
    playTone(250, 'triangle', 0.15, 0.1);
    setTimeout(() => playTone(200, 'triangle', 0.2, 0.1), 120);
  },
  win: () => {
    playTone(523.25, 'square', 0.2, 0.05);
    setTimeout(() => playTone(659.25, 'square', 0.2, 0.05), 150);
    setTimeout(() => playTone(783.99, 'square', 0.2, 0.05), 300);
    setTimeout(() => playTone(1046.50, 'square', 0.4, 0.05), 450);
  },
  lose: () => {
    playTone(400, 'sawtooth', 0.2, 0.05);
    setTimeout(() => playTone(350, 'sawtooth', 0.2, 0.05), 200);
    setTimeout(() => playTone(300, 'sawtooth', 0.2, 0.05), 400);
    setTimeout(() => playTone(250, 'sawtooth', 0.4, 0.05), 600);
  }
};
