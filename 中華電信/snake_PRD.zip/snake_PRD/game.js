// ==================== 階段 5：音效與優化 ====================
// 本階段實作音效系統、效能優化、錯誤處理

// ==================== 專案基礎設定與遊戲狀態管理 ====================

// 取得 DOM 元素
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const scoreElement = document.getElementById('scoreVal');
const highScoreElement = document.getElementById('highScoreVal');
const speedElement = document.getElementById('speedVal');
const startScreen = document.getElementById('startScreen');
const gameOverScreen = document.getElementById('gameOverScreen');
const finalScoreElement = document.getElementById('finalScore');
const newRecordElement = document.getElementById('newRecord');
const startBtn = document.getElementById('startBtn');
const restartBtn = document.getElementById('restartBtn');
const controlInstruction = document.getElementById('controlInstruction');
const controlKeys = document.getElementById('controlKeys');
const controlsText = document.getElementById('controlsText');
const soundToggle = document.getElementById('soundToggle');
const soundIcon = document.getElementById('soundIcon');
const soundText = document.getElementById('soundText');

// ==================== 5.1 & 5.2 音效系統 ====================

// 音效狀態
const SOUND_KEY = 'snakeSoundEnabled';
let soundEnabled = true;

// Web Audio API 設定
let audioContext = null;

/**
 * 初始化音效系統
 */
function initAudio() {
    try {
        // 創建 AudioContext（需要用戶互動後才能使用）
        audioContext = new (window.AudioContext || window.webkitAudioContext)();
    } catch (error) {
        console.warn('音效系統初始化失敗:', error);
        soundEnabled = false;
    }
}

/**
 * 播放音效
 * @param {number} frequency - 頻率（Hz）
 * @param {number} duration - 持續時間（秒）
 * @param {string} type - 音效類型（'food' 或 'gameover'）
 */
function playSound(frequency, duration, type = 'food') {
    if (!soundEnabled || !audioContext) {
        return;
    }
    
    try {
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        
        // 根據音效類型設定參數
        if (type === 'food') {
            // 吃到食物的音效：短促的高音
            oscillator.frequency.value = frequency;
            oscillator.type = 'sine';
            gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
            gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + duration);
        } else if (type === 'gameover') {
            // 遊戲結束的音效：低沉的音調
            oscillator.frequency.value = frequency;
            oscillator.type = 'sawtooth';
            gainNode.gain.setValueAtTime(0.2, audioContext.currentTime);
            gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + duration);
        }
        
        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + duration);
    } catch (error) {
        console.warn('播放音效失敗:', error);
    }
}

/**
 * 播放吃到食物的音效
 */
function playFoodSound() {
    playSound(800, 0.1, 'food');
}

/**
 * 播放遊戲結束的音效
 */
function playGameOverSound() {
    playSound(200, 0.3, 'gameover');
}

// ==================== 5.3 音效 UI 控制 ====================

/**
 * 載入音效設定
 */
function loadSoundSetting() {
    try {
        const saved = localStorage.getItem(SOUND_KEY);
        if (saved !== null) {
            soundEnabled = saved === 'true';
        }
        updateSoundUI();
    } catch (error) {
        console.warn('讀取音效設定失敗:', error);
    }
}

/**
 * 儲存音效設定
 */
function saveSoundSetting() {
    try {
        localStorage.setItem(SOUND_KEY, soundEnabled.toString());
    } catch (error) {
        console.warn('儲存音效設定失敗:', error);
    }
}

/**
 * 更新音效 UI
 */
function updateSoundUI() {
    if (soundEnabled) {
        soundIcon.textContent = '🔊';
        soundText.textContent = '音效: 開啟';
        soundToggle.classList.remove('muted');
    } else {
        soundIcon.textContent = '🔇';
        soundText.textContent = '音效: 關閉';
        soundToggle.classList.add('muted');
    }
}

/**
 * 切換音效開關
 */
function toggleSound() {
    soundEnabled = !soundEnabled;
    updateSoundUI();
    saveSoundSetting();
    
    // 如果開啟音效，初始化 AudioContext（需要用戶互動）
    if (soundEnabled && !audioContext) {
        initAudio();
    }
}

// 音效開關按鈕事件
soundToggle.addEventListener('click', toggleSound);

// 載入音效設定
loadSoundSetting();

// 在用戶第一次互動時初始化音效（瀏覽器要求）
document.addEventListener('click', () => {
    if (soundEnabled && !audioContext) {
        initAudio();
    }
}, { once: true });

// ==================== 響應式設計 - Canvas 與裝置檢測 ====================

// Canvas 目標尺寸
const TARGET_WIDTH = 800;
const TARGET_HEIGHT = 600;
const TARGET_ASPECT_RATIO = TARGET_WIDTH / TARGET_HEIGHT;

// 網格大小（每個格子 20 像素）
const BASE_GRID_SIZE = 20;

// 動態變數（會根據螢幕大小調整）
let canvasWidth = TARGET_WIDTH;
let canvasHeight = TARGET_HEIGHT;
let gridSize = BASE_GRID_SIZE;
let tileCountX = Math.floor(canvasWidth / gridSize);
let tileCountY = Math.floor(canvasHeight / gridSize);

/**
 * 檢測是否為觸控裝置
 * @returns {boolean} 是否為觸控裝置
 */
function isTouchDevice() {
    return 'ontouchstart' in window || navigator.maxTouchPoints > 0;
}

/**
 * 調整 Canvas 尺寸以適應螢幕
 */
function resizeCanvas() {
    try {
        const container = canvas.parentElement;
        if (!container) return;
        
        const containerWidth = container.clientWidth;
        const maxWidth = Math.min(containerWidth - 20, TARGET_WIDTH);
        
        // 計算適合的寬度和高度，保持寬高比
        let newWidth = maxWidth;
        let newHeight = newWidth / TARGET_ASPECT_RATIO;
        
        // 如果高度太大，以高度為準
        const maxHeight = window.innerHeight * 0.6;
        if (newHeight > maxHeight) {
            newHeight = maxHeight;
            newWidth = newHeight * TARGET_ASPECT_RATIO;
        }
        
        // 設定 Canvas 實際像素大小
        canvas.width = TARGET_WIDTH;
        canvas.height = TARGET_HEIGHT;
        
        // 設定 Canvas 顯示大小
        canvas.style.width = newWidth + 'px';
        canvas.style.height = newHeight + 'px';
        
        // 更新變數
        canvasWidth = TARGET_WIDTH;
        canvasHeight = TARGET_HEIGHT;
        gridSize = BASE_GRID_SIZE;
        tileCountX = Math.floor(canvasWidth / gridSize);
        tileCountY = Math.floor(canvasHeight / gridSize);
    } catch (error) {
        console.error('調整 Canvas 尺寸失敗:', error);
    }
}

// 初始化 Canvas 尺寸
resizeCanvas();

// 監聽視窗大小變化（使用防抖優化）
let resizeTimeout = null;
window.addEventListener('resize', () => {
    clearTimeout(resizeTimeout);
    resizeTimeout = setTimeout(() => {
        resizeCanvas();
        if (gameState === GAME_STATE.PLAYING || gameState === GAME_STATE.NOT_STARTED) {
            draw();
        }
    }, 100);
});

// 監聽螢幕方向變化
window.addEventListener('orientationchange', () => {
    setTimeout(() => {
        resizeCanvas();
        if (gameState === GAME_STATE.PLAYING || gameState === GAME_STATE.NOT_STARTED) {
            draw();
        }
    }, 100);
});

// ==================== 裝置檢測與 UI 調整 ====================

// 根據裝置類型調整操作說明
if (isTouchDevice()) {
    controlInstruction.textContent = '在遊戲畫面上滑動控制蛇的移動';
    controlKeys.textContent = '👆 👇 👈 👉';
    controlsText.textContent = '在遊戲畫面上滑動控制移動';
} else {
    controlInstruction.textContent = '使用鍵盤方向鍵控制蛇的移動';
    controlKeys.textContent = '↑ ↓ ← →';
    controlsText.textContent = '使用鍵盤方向鍵 (↑ ↓ ← →) 控制移動';
}

// 遊戲狀態管理（未開始/進行中/已結束）
const GAME_STATE = {
    NOT_STARTED: 'not_started',
    PLAYING: 'playing',
    GAME_OVER: 'game_over'
};

let gameState = GAME_STATE.NOT_STARTED;

// 初始化蛇的陣列（初始長度 4 節）
let snake = [
    { x: 10, y: 10 },
    { x: 9, y: 10 },
    { x: 8, y: 10 },
    { x: 7, y: 10 }
];

// 初始化食物位置變數
let food = { x: 0, y: 0 };

// 初始化移動方向變數（dx: 水平方向, dy: 垂直方向）
let dx = 1;  // 初始向右移動
let dy = 0;

// 初始化分數變數
let score = 0;

// ==================== 速度系統 ====================

// 速度系統設定
const BASE_SPEED = 8;  // 基礎速度（每秒更新次數）
const SPEED_INCREMENT = 0.5;  // 每次增加的速度
const SCORE_PER_LEVEL = 50;  // 每 50 分增加一級速度

// 當前遊戲速度（每秒更新次數）
let currentSpeed = BASE_SPEED;

// 當前速度等級
let speedLevel = 1;

/**
 * 計算當前速度等級
 * @returns {number} 速度等級
 */
function calculateSpeedLevel() {
    return Math.floor(score / SCORE_PER_LEVEL) + 1;
}

/**
 * 計算當前遊戲速度
 * @param {number} level - 速度等級
 * @returns {number} 每秒更新次數
 */
function calculateGameSpeed(level) {
    return BASE_SPEED + (level - 1) * SPEED_INCREMENT;
}

/**
 * 更新速度系統
 */
function updateSpeed() {
    const newLevel = calculateSpeedLevel();
    
    if (newLevel !== speedLevel) {
        speedLevel = newLevel;
        currentSpeed = calculateGameSpeed(speedLevel);
        if (speedElement) {
            speedElement.textContent = speedLevel;
        }
    }
}

let lastUpdateTime = 0;
let animationFrameId = null;

// ==================== 最高分記錄 ====================

// localStorage 的 key
const HIGH_SCORE_KEY = 'snakeHighScore';

// 最高分變數
let highScore = 0;

/**
 * 讀取最高分
 */
function loadHighScore() {
    try {
        const savedHighScore = localStorage.getItem(HIGH_SCORE_KEY);
        if (savedHighScore !== null) {
            highScore = parseInt(savedHighScore, 10);
            if (!isNaN(highScore) && highScoreElement) {
                highScoreElement.textContent = highScore;
            }
        }
    } catch (error) {
        console.warn('讀取最高分失敗:', error);
    }
}

/**
 * 儲存最高分
 */
function saveHighScore() {
    try {
        localStorage.setItem(HIGH_SCORE_KEY, highScore.toString());
    } catch (error) {
        console.warn('儲存最高分失敗:', error);
    }
}

/**
 * 檢查並更新最高分
 * @returns {boolean} 是否打破紀錄
 */
function checkAndUpdateHighScore() {
    if (score > highScore) {
        highScore = score;
        if (highScoreElement) {
            highScoreElement.textContent = highScore;
        }
        saveHighScore();
        return true;
    }
    return false;
}

// 初始化：載入最高分
loadHighScore();

// ==================== 重新開始功能 ====================

/**
 * 重置遊戲狀態
 */
function resetGame() {
    try {
        // 重置蛇的位置和長度
        snake = [
            { x: 10, y: 10 },
            { x: 9, y: 10 },
            { x: 8, y: 10 },
            { x: 7, y: 10 }
        ];
        
        // 重置移動方向
        dx = 1;
        dy = 0;
        
        // 重置分數
        score = 0;
        if (scoreElement) {
            scoreElement.textContent = score;
        }
        
        // 重置速度系統
        speedLevel = 1;
        currentSpeed = BASE_SPEED;
        if (speedElement) {
            speedElement.textContent = speedLevel;
        }
        
        // 隱藏新紀錄提示
        if (newRecordElement) {
            newRecordElement.classList.add('hidden');
        }
        
        // 重新生成食物
        generateFood();
        
        // 重置遊戲狀態
        gameState = GAME_STATE.PLAYING;
        
        // 隱藏所有畫面
        if (startScreen) startScreen.classList.add('hidden');
        if (gameOverScreen) gameOverScreen.classList.add('hidden');
        
        // 重置時間
        lastUpdateTime = 0;
        
        // 重新啟動遊戲循環
        if (animationFrameId) {
            cancelAnimationFrame(animationFrameId);
        }
        animationFrameId = requestAnimationFrame(gameLoop);
    } catch (error) {
        console.error('重置遊戲失敗:', error);
    }
}

/**
 * 開始遊戲
 */
function startGame() {
    resetGame();
}

// ==================== 開始畫面功能 ====================

if (startBtn) {
    startBtn.addEventListener('click', () => {
        startGame();
    });
}

// ==================== 遊戲結束畫面功能 ====================

/**
 * 顯示遊戲結束畫面
 */
function showGameOver() {
    try {
        gameState = GAME_STATE.GAME_OVER;
        
        if (finalScoreElement) {
            finalScoreElement.textContent = score;
        }
        
        // 播放遊戲結束音效
        playGameOverSound();
        
        // 檢查是否打破紀錄
        const isNewRecord = checkAndUpdateHighScore();
        if (newRecordElement) {
            if (isNewRecord) {
                newRecordElement.classList.remove('hidden');
            } else {
                newRecordElement.classList.add('hidden');
            }
        }
        
        if (gameOverScreen) {
            gameOverScreen.classList.remove('hidden');
        }
    } catch (error) {
        console.error('顯示遊戲結束畫面失敗:', error);
    }
}

if (restartBtn) {
    restartBtn.addEventListener('click', () => {
        startGame();
    });
}

// ==================== 繪製功能 ====================

/**
 * 清空畫布
 */
function clearCanvas() {
    if (!ctx) return;
    ctx.fillStyle = 'black';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
}

/**
 * 繪製蛇身
 */
function drawSnake() {
    if (!ctx) return;
    
    snake.forEach((segment, index) => {
        if (index === 0) {
            ctx.fillStyle = '#27ae60';  // 蛇頭：深綠色
        } else {
            ctx.fillStyle = '#2ecc71';   // 蛇身：淺綠色
        }
        ctx.fillRect(
            segment.x * gridSize, 
            segment.y * gridSize, 
            gridSize - 2, 
            gridSize - 2
        );
    });
}

/**
 * 繪製食物
 */
function drawFood() {
    if (!ctx) return;
    ctx.fillStyle = '#e74c3c';  // 紅色
    ctx.fillRect(
        food.x * gridSize, 
        food.y * gridSize, 
        gridSize - 2, 
        gridSize - 2
    );
}

/**
 * 繪製遊戲畫面（整合所有繪製功能）
 */
function draw() {
    if (!canvas || !ctx) return;
    clearCanvas();
    drawSnake();
    drawFood();
}

// ==================== 食物生成 ====================

/**
 * 隨機生成食物位置
 */
function generateFood() {
    let attempts = 0;
    const maxAttempts = 100;  // 防止無限遞迴
    
    do {
        food = {
            x: Math.floor(Math.random() * tileCountX),
            y: Math.floor(Math.random() * tileCountY)
        };
        
        // 檢查食物是否生成在蛇身上
        let isOnSnake = false;
        for (let segment of snake) {
            if (segment.x === food.x && segment.y === food.y) {
                isOnSnake = true;
                break;
            }
        }
        
        if (!isOnSnake) {
            return;  // 找到合適的位置
        }
        
        attempts++;
    } while (attempts < maxAttempts);
    
    // 如果嘗試多次仍無法找到合適位置，使用預設位置
    console.warn('無法找到合適的食物位置，使用預設位置');
    food = { x: 5, y: 5 };
}

// ==================== 蛇的移動邏輯 ====================

/**
 * 移動蛇
 */
function moveSnake() {
    if (gameState !== GAME_STATE.PLAYING) {
        return;
    }
    
    // 計算新蛇頭位置
    const newHead = {
        x: snake[0].x + dx,
        y: snake[0].y + dy
    };
    
    // 將新蛇頭加入陣列前端
    snake.unshift(newHead);
    
    // 檢查是否吃到食物
    if (newHead.x === food.x && newHead.y === food.y) {
        // 吃到食物：分數增加，生成新食物，不移除蛇尾（蛇變長）
        score += 10;
        if (scoreElement) {
            scoreElement.textContent = score;
        }
        
        // 播放吃到食物音效
        playFoodSound();
        
        // 更新速度系統
        updateSpeed();
        
        generateFood();
    } else {
        // 沒吃到食物：移除蛇尾（保持蛇的長度不變）
        snake.pop();
    }
}

// ==================== 碰撞檢測 ====================

/**
 * 檢查碰撞
 * @returns {boolean} 如果發生碰撞返回 true
 */
function checkCollision() {
    const head = snake[0];
    
    // 檢查牆壁碰撞（邊界檢查）
    if (head.x < 0 || head.x >= tileCountX || head.y < 0 || head.y >= tileCountY) {
        return true;
    }
    
    // 檢查自身碰撞（從索引 1 開始檢查）
    for (let i = 1; i < snake.length; i++) {
        if (head.x === snake[i].x && head.y === snake[i].y) {
            return true;
        }
    }
    
    return false;
}

/**
 * 處理碰撞（停止遊戲並顯示結束畫面）
 */
function handleCollision() {
    if (gameState === GAME_STATE.PLAYING) {
        showGameOver();
    }
}

// ==================== 觸控事件處理 ====================

// 觸控相關變數
let touchStartX = 0;
let touchStartY = 0;
const MIN_SWIPE_DISTANCE = 30;

/**
 * 改變移動方向
 * @param {number} newDx - 新的水平方向
 * @param {number} newDy - 新的垂直方向
 */
function changeDirection(newDx, newDy) {
    // 防止反向移動
    if ((newDx !== 0 && dx === -newDx) || (newDy !== 0 && dy === -newDy)) {
        return;
    }
    
    dx = newDx;
    dy = newDy;
}

if (canvas) {
    canvas.addEventListener('touchstart', (e) => {
        if (gameState !== GAME_STATE.PLAYING) {
            return;
        }
        
        e.preventDefault();
        
        const touch = e.touches[0];
        touchStartX = touch.clientX;
        touchStartY = touch.clientY;
    }, { passive: false });
    
    canvas.addEventListener('touchmove', (e) => {
        e.preventDefault();
    }, { passive: false });
    
    canvas.addEventListener('touchend', (e) => {
        if (gameState !== GAME_STATE.PLAYING) {
            return;
        }
        
        e.preventDefault();
        
        if (!e.changedTouches || e.changedTouches.length === 0) {
            return;
        }
        
        const touch = e.changedTouches[0];
        const touchEndX = touch.clientX;
        const touchEndY = touch.clientY;
        
        const deltaX = touchEndX - touchStartX;
        const deltaY = touchEndY - touchStartY;
        const distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
        
        if (distance < MIN_SWIPE_DISTANCE) {
            return;
        }
        
        const absDeltaX = Math.abs(deltaX);
        const absDeltaY = Math.abs(deltaY);
        
        if (absDeltaX > absDeltaY) {
            // 水平滑動
            changeDirection(deltaX > 0 ? 1 : -1, 0);
        } else {
            // 垂直滑動
            changeDirection(0, deltaY > 0 ? 1 : -1);
        }
    }, { passive: false });
}

// ==================== 鍵盤控制 ====================

window.addEventListener('keydown', (e) => {
    if (gameState !== GAME_STATE.PLAYING) {
        return;
    }
    
    switch(e.key) {
        case 'ArrowUp':
            if (dy !== 1) {
                changeDirection(0, -1);
            }
            break;
        case 'ArrowDown':
            if (dy !== -1) {
                changeDirection(0, 1);
            }
            break;
        case 'ArrowLeft':
            if (dx !== 1) {
                changeDirection(-1, 0);
            }
            break;
        case 'ArrowRight':
            if (dx !== -1) {
                changeDirection(1, 0);
            }
            break;
    }
});

// ==================== 遊戲主循環 ====================

/**
 * 更新遊戲邏輯
 */
function update() {
    if (gameState !== GAME_STATE.PLAYING) {
        return;
    }
    
    moveSnake();
    
    if (checkCollision()) {
        handleCollision();
    }
}

/**
 * 遊戲主循環（使用 requestAnimationFrame）
 * @param {number} currentTime - 當前時間戳
 */
function gameLoop(currentTime) {
    animationFrameId = requestAnimationFrame(gameLoop);
    
    if (gameState === GAME_STATE.PLAYING) {
        const secondsSinceLastUpdate = (currentTime - lastUpdateTime) / 1000;
        if (secondsSinceLastUpdate < 1 / currentSpeed) {
            return;
        }
        
        lastUpdateTime = currentTime;
        update();
        draw();
    } else {
        draw();
    }
}

// ==================== 初始化 ====================

// 初始化：生成第一個食物
generateFood();

// 繪製初始畫面
draw();

// 啟動遊戲循環
animationFrameId = requestAnimationFrame(gameLoop);
